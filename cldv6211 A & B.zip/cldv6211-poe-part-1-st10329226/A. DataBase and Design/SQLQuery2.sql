DROP TABLE IF EXISTS Booking; -- Drop Booking first, as it references Event and Venue
DROP TABLE IF EXISTS Event;   -- Drop Event next, as it references Venue
DROP TABLE IF EXISTS Venue;   -- Now you can drop Venue

CREATE TABLE Venue (
    VenueId INT PRIMARY KEY IDENTITY(1,1),
    VenueName VARCHAR(255) NOT NULL,
    Location VARCHAR(255) NOT NULL,
    Capacity INT NOT NULL,
    ImageUrl VARCHAR(2048)
);

CREATE TABLE Event (
    EventId INT PRIMARY KEY IDENTITY(1,1),
    EventName VARCHAR(255) NOT NULL,
    EventDate DATETIME NOT NULL,
    Description TEXT,
    VenueId INT,
    FOREIGN KEY (VenueId) REFERENCES Venue(VenueId)
);

CREATE TABLE Booking (
    BookingId INT PRIMARY KEY IDENTITY(1,1),
    EventId INT NOT NULL,
    VenueId INT NOT NULL,
    BookingDate DATETIME NOT NULL,
    FOREIGN KEY (EventId) REFERENCES Event(EventId),
    FOREIGN KEY (VenueId) REFERENCES Venue(VenueId)
);

INSERT INTO Venue (VenueName, Location, Capacity, ImageUrl) VALUES
('Grand Ballroom', 'Downtown', 500, 'https://via.placeholder.com/150'),
('Conference Hall A', 'Business Park', 200, 'https://via.placeholder.com/150'),
('Garden Terrace', 'Suburbs', 150, 'https://via.placeholder.com/150');

INSERT INTO Event (EventName, EventDate, Description, VenueId) VALUES
('Corporate Gala', '2024-12-15 19:00', 'Annual corporate gala', 1),
('Tech Seminar', '2024-12-20 10:00', 'Tech industry seminar', 2),
('Wedding Reception', '2024-12-22 18:00', 'Wedding reception', 3);

INSERT INTO Booking (EventId, VenueId, BookingDate) VALUES
(1, 1, '2024-12-01 10:00'),
(2, 2, '2024-12-05 14:00'),
(3, 3, '2024-12-08 16:00');